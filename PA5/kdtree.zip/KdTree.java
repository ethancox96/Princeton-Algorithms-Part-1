/******************************************************************************
 *  Compilation:  javac KdTree.java
 *  Execution:    java KdTree
 *  Dependencies: StdDraw.java StdRandom.java
 *
 *  Immutable point data type for points in the plane.
 *
 ******************************************************************************/

import java.util.Iterator;

public class KdTree
{
    public KdTree()
    {
        
    }
    
    public int size()
    {
        return 0;
    }
    
    public void insert(Point2D p)
    {
        
    }
    
    public boolean contains(Point2D p)
    {
        return false;
    }
    
    public void draw()
    {
        
    }
    
    public Iterable<Point2D> range(RectHV rect)
    {
        Stack<Point2D> points = new Stack<Point2D>();
        return points;
    }
    
    public Point2D nearest(Point2D p)
    {
        return p;
    }
}




